#include <stdio.h>
#include "Account.h"

/**
 * パスワード照合および連続失敗によるロック処理
 */
int authenticate_user(ACC *account, int input_password) {
    if (account->password_pin == input_password) {
        account->failed_auth_count = 0;
        return 1;
    } else {
        account->failed_auth_count++;
        if (account->failed_auth_count >= AUTH_RETRY_LIMIT) {
            account->is_active = 0; /* 規定回数以上の失敗で口座をロック */
        }
        return 0;
    }
}

/**
 * 現在時刻に基づいた手数料の算出
 */
int calculate_service_fee(int hour) {
    const int FREE_START_HOUR = 9;
    const int FREE_END_HOUR   = 18;

    if (hour < FREE_START_HOUR || hour >= FREE_END_HOUR) {
        return LATE_NIGHT_FEE_YEN; 
    }
    return 0;
}
