#ifndef ACCOUNT_H
#define ACCOUNT_H

/* システム共通定数 */
#define MAX_ACCOUNT_ENTRIES         (10)      /* 最大登録口座数 */
#define DAILY_WITHDRAW_LIMIT_YEN    (500000)  /* 1日の出金限度額 */
#define PASSWORD_RETRY_LIMIT        (3)       /* パスワード試行上限 */
#define SERVICE_FEE_YEN             (110)     /* 時間外手数料 */

/* 口座の状態定義 */
typedef enum {
    ACCOUNT_STATUS_LOCKED = 0,
    ACCOUNT_STATUS_ACTIVE = 1
} AccountStatus;

/* 口座情報構造体 */
typedef struct {
    int           account_id;       /* 口座番号 */
    char          owner_name[32];   /* 口座名義 */
    int           password;         /* 暗証番号（4桁） */
    int           balance_yen;      /* 現在の残高（単位：円） */
    AccountStatus status;           /* 口座状態（有効/ロック） */
    int           failed_auth_count;/* 認証失敗の累計回数 */
} Account;

#endif
