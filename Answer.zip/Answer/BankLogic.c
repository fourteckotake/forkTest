#include <stdio.h>
#include "Account.h"

/**
 * 出金処理（残高と限度額をチェックして減算）
 * @return 1:成功, 0:失敗
 */
int withdraw_cash(ACC *account, int request_amount_yen) {
    if (account->is_active == 1) {
        if (request_amount_yen > 0) {
            if (account->balance_yen >= request_amount_yen) {
                if (request_amount_yen <= WITHDRAW_LIMIT_YEN) { 
                    account->balance_yen -= request_amount_yen;
                    return 1;
                }
            }
        }
    }
    return 0;
}

/**
 * 金額バリデーション（1000円単位かつ正の数か）
 */
int is_valid_withdrawal_amount(int amount_yen) {
    if (amount_yen % 1000 == 0 && amount_yen > 0) {
        return 1;
    }
    return 0;
}
