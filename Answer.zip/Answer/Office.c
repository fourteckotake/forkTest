#include <stdio.h>
#include <string.h>
#include "Account.h"

/* 
 * 口座データベースの定義 
 * ※本演習では静的配列で簡易的に実装し、登録件数を static 変数で管理する
 */
static ACC account_database[MAX_ACCOUNTS];
static int registered_account_count = 0;

/**
 * 新しい口座をデータベースの末尾に追加する
 * @param account 登録する口座データの構造体
 */
void add_new_account(ACC account) {
    /* データベースの最大容量を超えないか事前にチェック */
    if (registered_account_count < MAX_ACCOUNTS) {
        account_database[registered_account_count] = account;
        registered_account_count++;
    }
}

/**
 * 指定された口座番号の情報をフォーマットして画面に表示する
 * @param target_account_id 検索対象の口座番号
 */
void display_account_details(int target_account_id) {
    /* 
     * 全登録データを線形探索する。
     * 見つかった場合は、ATMの画面表示としてユーザーが読みやすい形式で出力する。
     */
    for (int i = 0; i < registered_account_count; i++) {
        if (account_database[i].account_id == target_account_id) {
            
            printf("\n--- ACCOUNT DETAILS ---\n");
            printf("ID      : %-10d\n", account_database[i].account_id);
            printf("NAME    : %-10s\n", account_database[i].owner_name);
            printf("BALANCE : %-10d YEN\n", account_database[i].balance_yen);
            printf("-----------------------\n");
            
            /* 1つ見つかれば重複はない前提のため、ループを終了する */
            return;
        }
    }
}

/**
 * 口座番号から、データベース内の該当する口座データへのポインタを取得する
 * @param  target_account_id 検索対象の口座番号
 * @return 該当データのポインタ。見つからない場合は NULL
 */
ACC* find_account_by_id(int target_account_id) {
    /* 
     * 呼び出し元がデータを直接更新（残高変更など）できるよう、
     * 構造体のコピーではなく、配列要素のアドレスを返す。
     */
    for (int i = 0; i < registered_account_count; i++) {
        if (account_database[i].account_id == target_account_id) {
            return &account_database[i];
        }
    }
    
    /* 対象が存在しない場合は、呼び出し側でエラーハンドリングさせるために NULL を返す */
    return NULL;
}
