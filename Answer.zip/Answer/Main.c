#include <stdio.h>
#include "Account.h"

/* 外部関数のプロトタイプ宣言（リファクタリング後の名称） */
void add_new_account(ACC a);
void display_account_details(int id);
ACC* find_account_by_id(int id);
int  withdraw_cash(ACC *a, int m);
int  is_valid_withdrawal_amount(int m);
int  authenticate_user(ACC *a, int pw);
int  calculate_service_fee(int h);

int main() {
    /* 初期データ登録 */
    ACC initial_data = {101, "Taro Yamada", 1234, 50000, 1, 0};
    add_new_account(initial_data);

    /* ログイン処理 */
    int input_id;
    printf("PLEASE INSERT CARD (ID): ");
    scanf("%d", &input_id);

    ACC *current_user = find_account_by_id(input_id);

    /* 口座の存在とロック状態の確認 */
    if (current_user != NULL && current_user->is_active == 1) {
        int input_password;
        printf("ENTER 4-DIGIT PIN: ");
        scanf("%d", &input_password);

        if (authenticate_user(current_user, input_password)) {
            /* メインメニューループ */
            while (1) {
                int menu_selection;
                printf("\n1:BALANCE 2:WITHDRAW 3:EXIT\n> ");
                scanf("%d", &menu_selection);

                if (menu_selection == 1) {
                    display_account_details(current_user->account_id);
                } 
                else if (menu_selection == 2) {
                    int withdrawal_amount;
                    printf("ENTER AMOUNT: ");
                    scanf("%d", &withdrawal_amount);

                    if (is_valid_withdrawal_amount(withdrawal_amount)) {
                        int fee = calculate_service_fee(19); /* 19時として計算 */
                        if (withdraw_cash(current_user, withdrawal_amount + fee)) {
                            printf("SUCCESS. FEE: %d YEN\n", fee);
                        } else {
                            printf("ERROR: INSUFFICIENT BALANCE OR LIMIT OVER\n");
                        }
                    }
                } 
                else if (menu_selection == 3) {
                    break;
                }
            }
        } else {
            printf("AUTHENTICATION ERROR\n");
        }
    } else {
        printf("INVALID CARD OR ACCOUNT LOCKED\n");
    }

    return 0;
}


//コード改良版
// int main() {
//     // 1. 準備
//     setup_initial_data(); 

//     // 2. ログインフェーズ
//     input_id();
//     if (account_not_found || account_locked) {
//         print("利用できません");
//         return 0;
//     }

//     input_password();
//     if (!authenticate()) {
//         print("暗証番号エラー");
//         return 0;
//     }

//     // 3. サービス選択フェーズ
//     while (true) {
//         choice = select_menu(); // 1:残高, 2:引出, 3:終了

//         if (choice == 1) {
//             show_balance();
//         } 
//         else if (choice == 2) {
//             amount = input_amount();
//             fee = calculate_fee(time);
            
//             if (withdraw(amount + fee)) {
//                 print("完了 (手数料込み)");
//             } else {
//                 print("残高不足または限度額オーバー");
//             }
//         } 
//         else if (choice == 3) {
//             break; // ループ終了
//         }
//     }

//     return 0;
// }
