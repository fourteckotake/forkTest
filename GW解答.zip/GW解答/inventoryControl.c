#include <stdio.h>
#include <string.h>

#include "InventoryControl.h"

/* 
 * 内部状態（静的グローバル変数） 
 */
static Drink g_drinks[MAX_ENTRY];    /* 登録済みの飲み物リスト */
static int   g_drink_count = 0;      /* 現在の登録個数 */

/**
 * 名前から商品のインデックスを探す
 * @return 見つかった場合は添え字(0〜)、見つからない場合は -1
 */
int get_drink_index_by_name(const char* target_name) {
    for (int i = 0; i < g_drink_count; i++) {
        if (strcmp(g_drinks[i].name, target_name) == 0) {
            return i;
        }
    }
    return -1;
}

/**
 * 商品の新規登録
 */
void inv_add(Drink new_drink) {
    /* 1. ガード節で異常系を先に排除する */
    if (g_drink_count >= MAX_ENTRY) {
        printf("エラー: これ以上登録できません（最大 %d 件）。\n", MAX_ENTRY);
        return;
    }

    if (get_drink_index_by_name(new_drink.name) != -1) {
        printf("エラー: %s は既に登録されています。\n", new_drink.name);
        return;
    }

    /* 2. 正常系処理 */
    g_drinks[g_drink_count] = new_drink;
    g_drink_count++;
}

/**
 * 在庫を追加する
 */
void inv_add_stock(const char* name, int add_amount) {
    int index = get_drink_index_by_name(name);

    if (index == -1) {
        printf("エラー: %s が見つかりません。\n", name);
        return;
    }

    g_drinks[index].stock_count += add_amount;
}

/**
 * 全商品の初期在庫数を一括設定する
 */
void inv_set_initial_stock(int initial_amount) {
    for (int i = 0; i < g_drink_count; i++) {
        g_drinks[i].stock_count = initial_amount;
    }
}

/**
 * 商品一覧と詳細（特記事項）を表示
 */
void inv_display_goods_list(void) {
    printf("\n◆◆ 商品一覧 ◆◆\n");

    for (int i = 0; i < g_drink_count; i++) {
        Drink *d = &g_drinks[i]; /* 短いエイリアスで可読性向上 */

        printf("\n(%d) %-15s \t%d円\n", i + 1, d->name, d->price_yen);

        /* 種類に応じたラベルの表示（説明的なコード） */
        const char* label = "";
        switch (d->kind) {
            case DRINK_KIND_COFFEE: label = "豆原産地"; break;
            case DRINK_KIND_WATER:  label = "採水地";   break;
            case DRINK_KIND_TEA:    label = "茶葉種類"; break;
            default:                label = "備考";     break;
        }
        printf("  [ %s: %s ]\n", label, d->special_notes);
    }
    printf("\n");
}

/**
 * 商品を購入し、残金を返す
 * @return 購入後の残金。失敗時は -1
 */
int inv_buy_item(int deposit_money, int display_no) {
    /* 表示番号(1〜)を配列インデックス(0〜)に変換 */
    int index = display_no - 1;

    /* 範囲チェック */
    if (index < 0 || index >= g_drink_count) {
        printf("\nエラー: 正しい商品番号を選択してください。\n");
        return -1;
    }

    Drink *target = &g_drinks[index];

    /* 購入条件のチェック */
    if (target->stock_count <= 0) {
        printf("\n在庫切れ: %s は売り切れです。\n", target->name);
        return -1;
    }

    if (deposit_money < target->price_yen) {
        printf("\n金額不足: %d円 足りません。\n", target->price_yen - deposit_money);
        return -1;
    }

    /* 購入処理 */
    target->stock_count--;
    printf("\n【%s】を購入しました。\n", target->name);

    return deposit_money - target->price_yen;
}

/**
 * 在庫状況を一覧表示
 */
void inv_display_stock_list(void) {
    printf("\n◆◆ 在庫状況 ◆◆\n");
    for (int i = 0; i < g_drink_count; i++) {
        printf("(%d) %-15s ・・・・ %d本\n", 
               i + 1, g_drinks[i].name, g_drinks[i].stock_count);
    }
    printf("\n");
}
