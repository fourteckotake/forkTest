/**
 * Drink.h
 */
#ifndef DRINK_H
#define DRINK_H

/* マジックナンバーを名前付き定数にする */
#define DRINK_NAME_MAX    32
#define DRINK_MAKER_MAX   32
#define DRINK_NOTE_MAX    64

/* 飲み物の種類 */
typedef enum {
    DRINK_KIND_COFFEE,
    DRINK_KIND_WATER,
    DRINK_KIND_TEA
} DrinkKind;

/* 飲み物データ構造体 */
typedef struct {
    DrinkKind kind;               /* 種類 */
    char name[DRINK_NAME_MAX];    /* 商品名 */
    char maker[DRINK_MAKER_MAX];  /* メーカー名 */
    int  price_yen;               /* 価格（単位: 円） */
    int  is_cold;                 /* 1:Cold(冷), 0:Hot(温) */
    int  volume_ml;               /* 容量（単位: ml） */
    int  stock_count;             /* 在庫数 */
    char special_notes[DRINK_NOTE_MAX]; /* 特記事項 */
} Drink;

#endif
