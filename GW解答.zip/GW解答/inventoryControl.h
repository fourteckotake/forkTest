/**
 * InventoryControl.h
 */
#ifndef INVENTORY_CONTROL_H
#define INVENTORY_CONTROL_H

#include "VendingMachine.h"  /* タイポ修正: Machin -> Machine */
#include "Drink.h"

/*
 * 公開関数（プロトタイプ宣言）
 */

/**
 * 商品を新規登録する
 * @param drink 登録する飲み物データ
 */
void inv_add(Drink drink);

/**
 * 商品一覧（名前、価格、特記事項）を画面に表示する
 */
void inv_display_goods_list(void);

/**
 * 在庫状況の一覧を画面に表示する
 */
void inv_display_stock_list(void);

/**
 * 商品を購入処理し、残金を返す
 * @param deposit_money 投入金額
 * @param display_no    画面に表示されている商品番号 (1〜)
 * @return 購入後の残金。在庫不足や金額不足の場合は -1
 */
int inv_buy_item(int deposit_money, int display_no);

/**
 * 全商品の在庫数を一括で設定する（初期化用）
 * @param initial_stock_count 設定する在庫数
 */
void inv_set_initial_stock(int initial_stock_count);

#endif
