/**
 * VendingMachine.h
 */
#ifndef VENDING_MACHINE_H
#define VENDING_MACHINE_H

/* 
 * システム全体の定数定義
 */

/* 商品の最大登録可能数 */
#define MAX_DRINK_ENTRIES    (100)

/* 商品追加時のデフォルト在庫数 */
#define DEFAULT_STOCK_COUNT  (30)

#endif
