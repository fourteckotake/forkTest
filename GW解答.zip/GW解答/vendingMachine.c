#include <stdio.h>

#include "Drink.h"
#include "VendingMachine.h"
#include "InventoryControl.h"

/* 配列の要素数を計算するマクロ */
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))

/* 
 * 内部状態 
 */
static int g_deposited_money = 0; /* お客さまから預かった合計金額 */

/* 
 * プロトタイプ宣言（内部関数）
 */
static int  prompt_and_get_int(const char* prompt);
static void wait_for_enter(const char* prompt);
static void execute_purchase_flow(void);

/**
 * 自動販売機メインシステム
 */
int main(void) {
    /* 初期データの設定 */
    Drink initial_drinks[] = {
        {DRINK_KIND_COFFEE, "BOSS RAINBOW", "SUNTORY", 130, 1, 200, 10, "コロンビア"},
        {DRINK_KIND_COFFEE, "BOSS PREMIUM", "SUNTORY", 130, 1, 200, 10, "グアテマラ"},
        {DRINK_KIND_WATER,  "エビアン",      "DANONE",  100, 1, 350, 10, "フランス"},
        {DRINK_KIND_WATER,  "おいしい天然水", "SUNTORY", 130, 1, 500, 10, "富士山麓"},
        {DRINK_KIND_TEA,    "綾鷹 あやたか",  "COCA-COLA", 130, 1, 500, 10, "緑茶"},
        {DRINK_KIND_TEA,    "爽健美茶",      "COCA-COLA", 130, 1, 500, 10, "ブレンド茶"}
    };

    /* 標準出力のバッファリングを無効化（Eclipse等のコンソール対策） */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* 商品の登録 */
    for (int i = 0; i < ARRAY_SIZE(initial_drinks); i++) {
        inv_add(initial_drinks[i]);
    }

    /* メインループ */
    while (1) {
        printf("\n\n◆◆ 自動販売機 操作メニュー ◆◆\n");
        printf("(1) 商品を購入する\n");
        printf("(2) 在庫を確認する\n");
        printf("(3) 終了\n");
        
        int menu_choice = prompt_and_get_int("\n番号を入力してください > ");

        switch (menu_choice) {
            case 1:
                inv_display_goods_list();
                execute_purchase_flow();
                break;
            case 2:
                inv_display_stock_list();
                wait_for_enter("\n確認したら [Enter] を押してください > ");
                break;
            case 3:
                printf("システムを終了します。ご利用ありがとうございました。\n");
                return 0;
            default:
                printf("無効な番号です。もう一度入力してください。\n");
                break;
        }
    }
}

/**
 * 購入処理のワークフロー
 */
static void execute_purchase_flow(void) {
    int total_input = 0;

    while (1) {
        int input = prompt_and_get_int("\nお金を投入してください（0で戻る） > ");
        if (input == 0) return;

        total_input += input;
        g_deposited_money = total_input;

        int selected_no = prompt_and_get_int("商品番号を選んでください > ");

        /* 商品購入処理（残金を計算） */
        int change = inv_buy_item(g_deposited_money, selected_no);

        /* 購入失敗（在庫なし、金額不足等）の場合は再入力 */
        if (change < 0) {
            printf("現在の投入金額: %d円\n", g_deposited_money);
            continue; 
        }

        /* 購入成功 */
        if (change > 0) {
            printf("おつりは %d円 です。\n", change);
            wait_for_enter("\n商品とおつりをお取りください [Enter] > ");
        } else {
            printf("おつりはありません。\n");
            wait_for_enter("\n商品をお取りください [Enter] > ");
        }

        g_deposited_money = 0; /* 購入完了後は預り金をリセット */
        break;
    }
}

/**
 * 数値入力プロンプトを表示し、入力を受け取る
 */
static int prompt_and_get_int(const char* prompt) {
    int value;
    printf("%s", prompt);
    if (scanf("%d", &value) != 1) {
        /* 数値以外が入力された場合のバッファクリア */
        while (getchar() != '\n');
        return -1;
    }
    return value;
}

/**
 * Enterキーの入力を待つ
 */
static void wait_for_enter(const char* prompt) {
    printf("%s", prompt);
    /* scanfの後の改行コード等を飛ばす */
    fflush(stdin);
    while (getchar() != '\n');
}
