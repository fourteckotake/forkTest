#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

static int ninzu;
static int sum[5];
static char player[] = {'A','B','C','D','CPU'};
static char winner;
static char *ch = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
void diceroll_1(int turn);
//void result();

int main(void) {
	char str[10];
	int flag, i, dice1, dice2;

	setvbuf(stdout, NULL, _IONBF, 0);

	srand((unsigned int)time(NULL));

	printf("プレイヤー人数を入力してください(1～4名): ");
	gets(str);
	while(strstr(ch, str) != NULL)
	{
		printf("不正な入力です。1～4の数字を入力してください。: ");
		gets(str);
	}
	ninzu = atoi(str);
	while(ninzu < 1 || ninzu > 4)
	{
		printf("不正な入力です。1～4の数字を入力してください。: ");
		gets(str);
		ninzu = atoi(str);
	}
/*
	if(ninzu == 1)
	{
		while(sum[0] < 40 || sum[4] < 40)
		{
			printf("%cさんのターンです。1を入力してください。: ", player[0]);
			gets(str);
			while(strstr(ch, str) != NULL)
			{
				printf("不正な入力です。1を入力してください。: ");
				gets(str);
			}
			flag = atoi(str);
			while(flag != 1)
			{
				printf("不正な入力です。1を入力してください。: ");
				gets(str);
				flag = atoi(str);
			}
			if(flag == 1)
			{
				diceroll_1();
				printf("現在のマス\n");
				printf("Aさん:%d, CPU:%d\n", sum[0], sum[4]);
				printf("\n");
			}
		}
	}else if(ninzu == 2)
	{
*/		while(sum[0] < 40 || sum[1] < 40 || sum[2] < 40 || sum[3] < 40 || sum[4] < 40)
		{
			for(i = 0; i < ninzu; i++)
			{
				printf("%cさんのターンです。1を入力してください。: ", player[i]);
				gets(str);
				while(strstr(ch, str) != NULL)
				{
					printf("不正な入力です。1を入力してください。: ");
					gets(str);
				}
				flag = atoi(str);
				while(flag != 1)
				{
					printf("不正な入力です。1を入力してください。: ");
					gets(str);
					flag = atoi(str);
				}
				if(flag == 1)
				{
					diceroll_1(i);

//					dice1 = rand() % 6 + 1;
//					dice2 = rand() % 6 + 1;
//					sum[i] = dice1 + dice2 + sum[i];
//					printf("サイコロの目は%dと%dです。\n\n", dice1, dice2);
				}
			}
				printf("CPUのターンです。\n");
				diceroll_1(4);

//				dice1 = rand() % 6 + 1;
//				dice2 = rand() % 6 + 1;
//				sum[4] = dice1 + dice2 + sum[4];
//				printf("サイコロの目は%dと%dです。\n\n", dice1, dice2);
				printf("現在のマス\n");
				for(i=0;i<ninzu;i++){
					printf("%cさん:%d, ",player[i],sum[i]);
				}
				printf("CPU:%d\n",  sum[4]);
				printf("\n");

		}
	//}
}

//サイコロを振る(a[]:プレイヤー人数保持配列 s[]:プレイヤーの総合計保持配列 n:プレイヤー人数)
void diceroll_1(int turn)
{
	int dice1,dice2,i,j;
	dice1 = rand() % 6 + 1;
	dice2 = rand() % 6 + 1;
	sum[turn] = dice1 + dice2 + sum[turn];
	printf("サイコロの目は%dと%dです。\n\n", dice1, dice2);

	if(sum[turn] >= 40 && sum[4] < 40)
	{
		printf("ゴール時のマス\n");
		for(i=0;i<ninzu;i++){
			printf("%cさん:%d, ",player[i],sum[i]);
		}
		printf("CPU:%d\n",  sum[4]);
		printf("\n");
		printf("%cさんの勝利です。\n",player[turn]);
		printf("\n全体：");

		for(j = 0; j < 41;j++){
			printf("%2d",j);
		}
		printf("\n");
		for(i = 0; i < ninzu; i++){
			printf("%c   ：",player[i]);
			for(j = 0; j < sum[i]; j++){
				if(j >= 40){
					printf("Ｇ");
					break;
				}else{
					printf("○");
				}
			}
			printf("\n");
		}
		printf("CPU ：");
		for(j = 0; j < sum[4]; j++){
			if(j >= 40){
				printf("Ｇ");
				break;
			}else{
				printf("○");
			}
		}
		printf("\n");
		exit(0);
	}
//	printf("CPUのターンです。\n");
//	dice1 = rand() % 6 + 1;
//	dice2 = rand() % 6 + 1;
//	sum[4] = dice1 + dice2 + sum[4];
//	printf("サイコロの目は%dと%dです。\n\n", dice1, dice2);
/*	if(sum[4] >= 40 && sum[0] < 40)
	{
		printf("ゴール時のマス\n");
		printf("Aさん:%d, CPU:%d\n", sum[0], sum[4]);
		printf("CPUの勝利です。\n");

		printf("\n全体：");

		for(j = 0; j < 41; j++){
			printf("%2d",j);
		}
		printf("\n");
		for(i = 0; i < ninzu; i++){
			printf("%4c：",player[i]);
			for(j = 0; j < sum[i]; j++){
				if(j >= 40){
					printf("Ｇ");
					break;
				}else{
					printf("○");
				}
			}
			printf("\n");
		}
		printf("CPU ：");
		for(j = 0; j < sum[4]; j++){
			if(j >= 40){
				printf("Ｇ");
				break;
			}else{
				printf("○");
			}
		}
		printf("\n");
		exit(0);
	}
*/
}
