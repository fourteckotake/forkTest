#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <time.h>

int playersTurn(int player[9], int dealer[9]);
int dealersTurn(int dealer[9]);
int check(char temp[10]);
int stand(int card[9]);
void hit(int tru[9]);
void winer(int sumplayer, int sumdealer);
void showMessage(int a);
void showCard(int card[9], int modle);
int trump[13] = {0};

int main(void) {
	int player[9] = {0}, dealer[9] = {0}, sump, sumd;
	int i, flog;
	char temp[10];

	setvbuf(stdout, NULL,_IONBF, 0);

	srand(time(0));

	while(1) {
		showMessage(0);
		gets(temp);
		flog = check(temp);

		if(flog == 1){
			for(i = 0; i < 2; i++){
				hit(dealer);
				hit(player);
			}
			sump = playersTurn(player, dealer);
			sumd = dealersTurn(dealer);

			winer(sump, sumd);
		}
		else if(flog == 2){
			printf("また今度\n");
			exit(1);
		}
		else if(flog == 0){
			showMessage(9);
		}
	}
}

int playersTurn(int player[9], int dealer[9])
{
	int flog,sum;
	char temp[10];

	showMessage(1);
	showCard(dealer, 1);

	showMessage(2);
	showCard(player, 2);

	while(1){
		showMessage(3);
		gets(temp);
		flog = check(temp);
		if(flog == 3){
			hit(player);
			sum = stand(player);
			showMessage(2);
			showCard(player, 2);
		}
		if(sum==0){
			showMessage(5);
			showMessage(7);
			exit(1);
		}
		else if(flog == 4){
			sum = stand(player);
			break;
		}
		else if(flog == 0){
			showMessage(9);
		}
	}
return sum;
}

int dealersTurn(int dealer[9])
{
	int sum;
	showCard(dealer,1);
	sum = stand(dealer);

	while(sum <= 17){
		showMessage(4);
		hit(dealer);
		sum = stand(dealer);
		showMessage(1);
		showCard(dealer, 2);
		if(sum==0){
			showMessage(5);
			showMessage(6);
			exit(1);
		}
	}
return sum;
}

int check(char temp[10])
{
	int flog;

	if(temp[0] == 'y' || temp[0] == 'Y'){
		flog = 1;
	}
	else if(temp[0] == 'n' || temp[0] == 'N'){
		flog = 2;
	}
	else if(temp[0] == 'h' || temp[0] == 'H'){
		flog = 3;
	}
	else if(temp[0] == 's' || temp[0] == 'S'){
		flog = 4;
	}
	else{
		flog = 0;
	}
return flog;
}

int stand(int card[9])
{
	int i, sum=0;

	for(i = 0; i < 9 && card[i] != 0; i++){
		if(sum <= 10 && card[i] == 1){
			sum = sum + 11;
		}
		else if(sum > 10 && card[i] == 1){
			sum = sum + 1;
		}
		else if(card[i] == 11 || card[i] == 12 || card[i] == 13){
			sum = sum + 10;
		}else
		sum = sum + card[i];
	}

	if(sum > 21){
		sum = 0;
		return sum;
	}
	else
		return sum;
}
void hit(int tru[9])
{
	int i, itemp;

	for(i = 0; i < 9; i++){
		if(tru[i] == 0){
			while(1){
				itemp = rand() % 13 + 1;
				trump[itemp-1]++;
				if(trump[itemp-1] <= 4){
					break;
				}
			}
			tru[i] = itemp;

			break;
		}
	}
}

void winer(int sumplayer, int sumdealer)
{
	int result;

	result = sumplayer - sumdealer;

	if(result > 0){			//プレイヤーの方が大きい場合
		showMessage(6);
	}
	if(result == 0){		//引き分けの場合
		showMessage(8);
	}
	if(result < 0){			//ディーラーの方が大きい場合
		showMessage(7);
	}
}

void showMessage(int num)
{
	switch(num){
		case 0: printf("Welcome to BlackJack 勝負しますか?(Y/N)：");
		break;
		case 1: printf("ディーラーのカード：");
		break;
		case 2: printf("自分のカード：");
		break;
		case 3: printf("HIT(引く)orSTAND(引かない)(H/S)：");
		break;
		case 4: printf("ディーラーがHIT\n");
		break;
		case 5: printf("バスト(bust)!!!\n");
		break;
		case 6: printf("☆★☆★YOU WIN☆★☆★\n");
		break;
		case 7: printf("～～～～YOU LOSE～～～～\n");
		break;
		case 8: printf("引き分け\n");
		break;
		case 9: printf("指定の文字を入力してください\n");
		break;
	}
}

void showCard(int card[9], int modle)
{
	int i;

	switch(modle){
		case 1:{
			if(card[1] == 1){
				printf("○ A\n");
			}else if(card[1] == 11){
				printf("○ J\n");
			}else if(card[1] == 12){
				printf("○ Q\n");
			}else if(card[1] == 13){
				printf("○ K\n");
			}else{
				printf("○ %d\n", card[1]);
			}
			break;
		}

		case 2:{
			for(i = 0; i < 9 && card[i] != 0; i++){
				if(card[i] == 1){
					printf("A ");
				}else if(card[i] == 11){
					printf("J ");
				}else if(card[i] == 12){
					printf("Q ");
				}else if(card[i] == 13){
					printf("K ");
				}else{
					printf("%d ", card[i]);
				}
			}
			printf("\n");
			break;
		}
	}
}
