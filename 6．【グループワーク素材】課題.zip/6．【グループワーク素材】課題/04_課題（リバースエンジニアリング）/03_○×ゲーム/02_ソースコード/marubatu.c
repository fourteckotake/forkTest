#include<stdio.h>
#include<string.h>

int winer;	//○が勝ち1,×が勝ち2,ひきわけ3
int math[10];	//マス目
char temp[100];		//99文字の入力まで対応可能
int i;
int f;
int player;	//○1,×2

void reset(void){
	player = 1;
	winer = 0;
	i = 0;

	for(f = 0; f < 9; f++){		//マス目(math)を空白("　")で初期化
		math[f] = 0;
	}

	f = 0;

	printf("右側の番号どおりに入力するとその位置に自分のマーク(○×)が入ります");
	printf("\n");
}

void print_math_1(void){

	printf("|");
	for(f = 0; f < 3; f++){
		if(math[f+6] == 0){
			printf("　|");
		}else if(math[f+6] == 1){
			printf("○|");
		}else if(math[f+6] == 2){
			printf("×|");
		}else{
			printf("??|");
		}
	}
	printf("\t|７|８|９|");
	printf("\n");

}

void print_math_2(void){

	printf("|");
	for(f = 0; f < 3; f++){
		if(math[f+3] == 0){
			printf("　|");
		}else if(math[f+3] == 1){
			printf("○|");
		}else if(math[f+3] == 2){
			printf("×|");
		}else{
			printf("??|");
		}
	}
	printf("\t|４|５|６|");
	printf("\n");

}

void print_math_3(void){

	printf("|");
	for(f = 0; f < 3; f++){
		if(math[f] == 0){
			printf("　|");
		}else if(math[f] == 1){
			printf("○|");
		}else if(math[f] == 2){
			printf("×|");
		}else{
			printf("??|");
		}
	}
	printf("\t|１|２|３|");
	printf("\n");

}

void print_math(void){

	printf("―――――\t―――――");
	printf("\n");
	print_math_1();	//マスの1行目を表示
	print_math_2();	//マスの2行目を表示
	print_math_3();	//マスの3行目を表示
	printf("―――――\t―――――");
	printf("\n");
	printf("\n");

}

int double_check(int flag){
	if((math[flag-1] == 0) != 0){	//マス目
		return flag;
	}else{
		return -1;
	}
}

int input_check(void){
	int flag;

	if(player == 1){
		printf("○の番です。(半角数字で入力)：");
/*		player = 2;*/
	}else{
		printf("×の番です。(半角数字で入力)：");
/*		player = 1;*/
	}

	fflush(stdout);

	gets(temp);
	if(strlen(temp) > 1){
		return -1;
	}else{
		switch(temp[0]){
			case '1':flag = 1;break;
			case '2':flag = 2;break;
			case '3':flag = 3;break;
			case '4':flag = 4;break;
			case '5':flag = 5;break;
			case '6':flag = 6;break;
			case '7':flag = 7;break;
			case '8':flag = 8;break;
			case '9':flag = 9;break;
			default:return -1;
		}
		flag = double_check(flag);
		if(flag == -1){
			return -1;
		}else{
			return flag;
		}
	}

}

void input(void){
	int flag;
	while(1){
		flag = input_check();
		if(flag != -1){
			if(player == 2){
				math[flag-1] = 2;
				player = 1;
				break;
			}else if(player == 1){
				math[flag-1] = 1;
				player = 2;
				break;
			}

		}else{
			printf("入力エラー。もう一度入力してください");
			printf("\n");

		}
	}
}

void winer_check(void){
	if((math[6] == math[7]) && (math[7] == math[8])){
		if((math[8] == 1)){
			winer = 1;
		}else if((math[8] == 2)){
			winer = 2;
		}
	}else if((math[3] == math[4]) && (math[4] == math[5])){
		if(math[5] == 1){
			winer = 1;
		}else if(math[5] == 2){
			winer = 2;
		}
	}else if((math[0] == math[1]) && (math[1] == math[2])){
		if(math[3] == 1){
			winer = 1;
		}else if(math[3] == 2){
			winer = 2;
		}
	}else if((math[6] == math[3]) && (math[3] == math[0])){
		if(math[0] == 1){
			winer = 1;
		}else if(math[0] == 2){
			winer = 2;
		}
	}else if((math[7] == math[4]) && (math[4] == math[1]) ){
		if(math[1] == 1){
			winer = 1;
		}else if(math[1] == 2){
			winer = 2;
		}
	}else if((math[8] == math[5])  && (math[5] == math[2])){
		if(math[2] == 1){
			winer = 1;
		}else if(math[2] == 2) {
			winer = 2;
		}
	}else if((math[6] == math[4]) && (math[4] == math[2])){
		if(math[2] == 1){
			winer = 1;
		}else if(math[2] == 2){
			winer = 2;
		}
	}else if((math[8] == math[4])  && (math[4] == math[0]) ){
		if(math[0] == 1){
			winer = 1;
		}else if(math[0] == 2){
			winer = 2;
		}
	}else{
		for(f = 0; f < 9; f++){
			if((math[f] == 0) == 0){
				break;
			}
		}
		if(f == 9){
			winer = 3;
		}
	}
}

void print_winer(void){
	switch(winer){
		case 1:
			printf("○の勝利です");
			printf("\n");
			break;
		case 2:
			printf("×の勝利です");
			printf("\n");
			break;
		case 3:
			printf("ひきわけです");
			printf("\n");
			break;
	}
}

int main(void) {

	setvbuf(stdout, NULL, _IONBF, 0);

	reset();
	print_math();
	while(winer == 0){
		input();
		print_math();
		winer_check();
	}
	print_winer();

return 0;
}
