#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define PLAYER_N_MAX 4	//プレイヤーの最大人数
#define MASU_MAX 40		//すごろくのマス目の数(ゴール位置は39)
#define LNAME 11		//プレイヤー名の長さの最大値
#define LINPUT 11		//入力値の長さの最大値
#define CPU -1			//CPUであることを表す値
#define ERROR -99999	//エラーや例外を表す値


struct data{
	char name[LNAME];	//プレイヤー名(CPU名)
	int masu;			//プレイヤー(CPU)の現在位置
}player[PLAYER_N_MAX],cpu;

int player_n_max;		//プレイヤーの参加人数

void print_error(int f) {
	if((f >= 1) && (f <= PLAYER_N_MAX)){
		printf("1～4の数字を入力してください");
		printf("\n");
	}else{
		printf("()内の数値を入力してください");
		printf("\n");
	}
}

void print_masu(int index,int p_or_c) {
	int i;

	if(p_or_c != CPU){
		printf(" %s ",player[p_or_c].name);
	}else{
		printf("%s ",cpu.name);
	}
	for(i = 0; i < MASU_MAX; i++){
		if(i != index){
			printf("○");
		}else{
			printf("●");
		}
	}
	printf("\n");
}

int check(char str[]) {

	if(strlen(str) > 1) {
		return ERROR;
	}else{
		switch(str[0]) {
			case '1':
				return 1;
			case '2':
				return 2;
			case '3':
				return 3;
			case '4':
				return 4;
			default:
				return ERROR;
		}
	}
}

void input_n(void) {
	char input[LINPUT];
	int i;

	while(1) {
		printf("参加者の人数は？：");
		gets(input);
		i = check(input);

		if(i != ERROR) {
			player_n_max = i;
			break;
		}else{
			print_error(1);
		}
	}

	printf("参加者は ");
	for(i = 0; i < player_n_max; i++) {
		printf("%s ",player[i].name);
	}
	printf("です\n");

	for(i = 0; i < player_n_max; i++) {
		print_masu(0,i);
	}
	print_masu(0,CPU);
	printf("\n");
}

void saikoro(int p) {
	int r1,r2;
	int f;
	char input[LINPUT];

	r1 = rand() % 6 + 1;
	r2 = rand() % 6 + 1;
	if(p != CPU) {
		while(1) {
			printf("%sがサイコロを振る(%d)：",player[p].name,p+1);
			gets(input);
			f = check(input);
			if(f == p+1) {
				break;
			}else{
				print_error(ERROR);
			}
		}
		f = r1 + r2;
		printf("%d %d  %dマス進む",r1,r2,f);
		printf("\n");
		player[p].masu += f;
		if(player[p].masu >= MASU_MAX) {
			player[p].masu = MASU_MAX-1;
		}
		print_masu(player[p].masu,p);
	}else{
		printf("%sがサイコロを振る",cpu.name);
		printf("\n");
		f = r1 + r2;
		printf("%d %d  %dマス進む",r1,r2,f);
		printf("\n");
		cpu.masu += f;
		if(cpu.masu >= MASU_MAX) {
			cpu.masu = MASU_MAX-1;
		}
		print_masu(cpu.masu,CPU);
	}
}

void print_winer(int f) {
	if(f != CPU) {
		printf("%sがゴールしました",player[f].name);
		printf("\n");
		printf("勝者は%sです",player[f].name);
		printf("\n");
	} else {
		printf("%sがゴールしました",cpu.name);
		printf("\n");
		printf("勝者は%sです",cpu.name);
		printf("\n");
	}

}

void sugoroku(void) {
	int i;
	int f = ERROR;

	while(1) {
		for(i = 0; i < player_n_max; i++) {
			saikoro(i);
			if(player[i].masu >= MASU_MAX-1) {
				f = i;
				break;
			}
		}
		if(f != ERROR) {
			break;
		}else{
			saikoro(CPU);
			if(cpu.masu >= MASU_MAX-1) {
				f = CPU;
				break;
			}
		}
		printf("\n");
	}
	print_winer(f);
}

int main(void) {

	setvbuf(stdout, NULL, _IONBF, 0);

	strcpy(player[0].name,"P1");
	strcpy(player[1].name,"P2");
	strcpy(player[2].name,"P3");
	strcpy(player[3].name,"P4");
	strcpy(cpu.name,"CPU");
	srand(time(0));
	input_n();
	sugoroku();
	return 0;
}
